var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602122001546.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602122001546-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Home Screen" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1602122001546.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1602122001546-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1602122001546-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1279.0px" datasizeheight="800.0px" dataX="1.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d3ef318d-6cf4-4cf2-b18e-2888ebdcc71a.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="1279.0px" datasizeheight="145.0px" datasizewidthpx="1279.0000000000002" datasizeheightpx="145.0" dataX="1.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="300.0px" datasizeheight="115.0px" datasizewidthpx="300.0" datasizeheightpx="115.0" dataX="754.0" dataY="310.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="646.0px" datasizeheight="111.0px" dataX="320.0" dataY="17.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Tiger Rewards</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="300.0px" datasizeheight="115.0px" datasizewidthpx="300.0" datasizeheightpx="115.0" dataX="227.0" dataY="310.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer mousedown mouseup click mouseenter mouseleave ie-background commentable non-processed" customid="Paragraph 2"   datasizewidth="300.0px" datasizeheight="115.0px" dataX="227.0" dataY="310.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0"><br /><br /><br /></span><span id="rtr-s-Paragraph_2_1">LOGIN</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer click mousedown mouseenter mouseleave ie-background commentable non-processed" customid="Paragraph 2"   datasizewidth="300.0px" datasizeheight="115.0px" dataX="754.0" dataY="310.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0"><br /><br /><br /></span><span id="rtr-s-Paragraph_3_1">SIGN UP</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 4"   datasizewidth="646.0px" datasizeheight="44.0px" datasizewidthpx="645.9999999999999" datasizeheightpx="44.0" dataX="320.0" dataY="168.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="646.0px" datasizeheight="29.0px" dataX="320.0" dataY="173.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">A system that rewards YOU for keeping your campus clean</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_1" customid="Line 1" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="7" datasizewidth="1280.0px" datasizeheight="2.0px" datasizewidthpx="1280.0000000000007" datasizeheightpx="2.0" dataX="-0.0" dataY="144.5" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 1" d="M 0.0 1.0 L 1280.0000000000007 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_2" customid="Line 3" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="646.0px" datasizeheight="2.0px" datasizewidthpx="645.9999999999999" datasizeheightpx="2.0" dataX="320.0" dataY="211.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 3" d="M 0.0 1.0 L 645.9999999999999 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 5"   datasizewidth="134.7px" datasizeheight="111.0px" dataX="85.0" dataY="17.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">TR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_3" customid="Line 2" class="shapewrapper shapewrapper-s-Line_3 non-processed"  rotationdeg="90" datasizewidth="109.0px" datasizeheight="2.0px" datasizewidthpx="109.0" datasizeheightpx="2.0" dataX="220.0" dataY="71.5" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 1.0 L 109.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;