var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602122001546.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602122001546-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-56859ee9-37a8-4794-9e05-a83e3d66248a" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Balance check" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/56859ee9-37a8-4794-9e05-a83e3d66248a-1602122001546.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/56859ee9-37a8-4794-9e05-a83e3d66248a-1602122001546-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/56859ee9-37a8-4794-9e05-a83e3d66248a-1602122001546-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="1281.0px" datasizeheight="86.0px" datasizewidthpx="1281.0" datasizeheightpx="86.00000000000003" dataX="-0.5" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Paragraph 2"   datasizewidth="98.2px" datasizeheight="74.0px" dataX="14.5" dataY="6.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">TR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="311.0px" datasizeheight="79.0px" dataX="125.5" dataY="23.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Balance Check</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_1" customid="Line 2" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="89" datasizewidth="55.0px" datasizeheight="2.0px" datasizewidthpx="55.0" datasizeheightpx="2.0" dataX="87.5" dataY="42.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 1.0 L 55.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="765.0px" datasizeheight="666.0px" datasizewidthpx="765.0000000000005" datasizeheightpx="666.0000000000005" dataX="257.5" dataY="86.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 3"   datasizewidth="362.0px" datasizeheight="43.0px" dataX="470.0" dataY="127.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">TR Balance Checker</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="256.0px" datasizeheight="37.0px" dataX="512.0" dataY="170.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Check your Tiger Rewards Balance</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 5"   datasizewidth="0.0px" datasizeheight="16.0px" dataX="415.9" dataY="221.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 6"   datasizewidth="691.0px" datasizeheight="34.0px" dataX="294.5" dataY="253.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">You have (Points) points. You are (Points) points from your goal.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table_1" class="pie table firer commentable non-processed" customid="Table 1"  datasizewidth="511.7px" datasizeheight="419.7px" dataX="384.2" dataY="302.0" originalwidth="510.6666666666668px" originalheight="418.66666666666845px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Text_cell_17" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 1"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_17_0">Date</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_18" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 4"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_18_0">Spent / Gained</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_19" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 2"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_19_0">10/3/2020</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_20" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 5"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_20_0">+754</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_21" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 3"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_21_0">10/4/2020</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_22" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 6"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_22_0">-400</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_23" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 7"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_23_0"></span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_24" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 8"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_24_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_25" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 9"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_25_0"></span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_26" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 10"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_26_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_27" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 11"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_27_0"></span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_28" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 12"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_28_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_29" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 13"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_29_0"></span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_30" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 14"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_30_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_31" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 15"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_31_0"></span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_32" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 16"     datasizewidth="256.3px" datasizeheight="53.3px" dataX="0.0" dataY="0.0" originalwidth="255.33333333333348px" originalheight="52.33333333333357px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_32_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;