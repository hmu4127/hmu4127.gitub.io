var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602122001546.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602122001546-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-8ee17b5d-ce74-464d-8763-a75cc3589538" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Point Redeem" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/8ee17b5d-ce74-464d-8763-a75cc3589538-1602122001546.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/8ee17b5d-ce74-464d-8763-a75cc3589538-1602122001546-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/8ee17b5d-ce74-464d-8763-a75cc3589538-1602122001546-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="1281.0px" datasizeheight="86.0px" datasizewidthpx="1281.0" datasizeheightpx="86.00000000000003" dataX="-0.5" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Paragraph 2"   datasizewidth="98.2px" datasizeheight="74.0px" dataX="14.5" dataY="6.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">TR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="311.0px" datasizeheight="79.0px" dataX="125.5" dataY="23.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Point Redeemer</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_1" customid="Line 2" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="89" datasizewidth="55.0px" datasizeheight="2.0px" datasizewidthpx="55.0" datasizeheightpx="2.0" dataX="87.5" dataY="42.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 1.0 L 55.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Category_1" class="pie checkboxlist firer commentable non-processed" customid="Category 1"    datasizewidth="473.0px" datasizeheight="620.0px" dataX="403.5" dataY="102.0"  tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="scroll">\
            <div class="paddingLayer">\
              <table class="collapse" style="height: 100%; width: 100%;" summary="">\
                <tbody>\
                  <tr>\
                    <td>\
                        <input type="checkbox" name="s-Category_1"   tabindex="-1" ></div>\
                        <span class="option">Reward 1 (Cost)</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <input type="checkbox" name="s-Category_1"   tabindex="-1" ></div>\
                        <span class="option">Reward 2 (Cost)</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <input type="checkbox" name="s-Category_1"   tabindex="-1" ></div>\
                        <span class="option">Reward 3 (Cost)</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <input type="checkbox" name="s-Category_1"   tabindex="-1" ></div>\
                        <span class="option">Reward 4 (Cost)</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <input type="checkbox" name="s-Category_1"   tabindex="-1" ></div>\
                        <span class="option">Reward 5 (Cost)</span>\
                    </td>\
                  </tr>\
                  <tr>\
                    <td>\
                        <input type="checkbox" name="s-Category_1"   tabindex="-1" ></div>\
                        <span class="option">Reward 6 (Cost)</span>\
                    </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Button 1"   datasizewidth="186.0px" datasizeheight="65.0px" dataX="547.0" dataY="722.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Purchase</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer pageload ie-background commentable non-processed" customid="Paragraph 3"   datasizewidth="498.0px" datasizeheight="74.0px" dataX="391.0" dataY="274.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Items Purchased!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;