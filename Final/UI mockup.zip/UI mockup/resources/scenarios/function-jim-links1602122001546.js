(function(window, undefined) {

  var jimLinks = {
    "06f87fda-20e2-4200-982c-f716ff064826" : {
      "Paragraph_1" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ],
      "Paragraph_2" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ],
      "Paragraph_3" : [
        "11ab9acc-0d15-4821-b2c4-0eeaf8bb8e97"
      ],
      "Paragraph_4" : [
        "3ebd9f51-6701-4e73-a2b8-5102a17823af"
      ],
      "Paragraph_5" : [
        "56859ee9-37a8-4794-9e05-a83e3d66248a"
      ],
      "Paragraph_6" : [
        "64e9d709-c724-47bf-a13e-0c7141f1ce97"
      ],
      "Paragraph_7" : [
        "8ee17b5d-ce74-464d-8763-a75cc3589538"
      ]
    },
    "23eb2b4b-a1bd-4696-aa07-21e4749fdb2a" : {
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "c0a64e40-7542-45e9-8844-6623c6c0b17a" : {
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_8" : [
        "fc609c7f-6e37-4c8f-a46e-f6522662c61f"
      ],
      "Paragraph_9" : [
        "23eb2b4b-a1bd-4696-aa07-21e4749fdb2a"
      ],
      "Button_1" : [
        "06f87fda-20e2-4200-982c-f716ff064826",
        "06f87fda-20e2-4200-982c-f716ff064826"
      ]
    },
    "11ab9acc-0d15-4821-b2c4-0eeaf8bb8e97" : {
      "Paragraph_12" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ],
      "Paragraph_13" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ]
    },
    "3ebd9f51-6701-4e73-a2b8-5102a17823af" : {
      "Paragraph_1" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ],
      "Paragraph_2" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ]
    },
    "8ee17b5d-ce74-464d-8763-a75cc3589538" : {
      "Paragraph_1" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ],
      "Paragraph_2" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ]
    },
    "d77f7d0c-efbd-4b3a-a517-656d9fa9c17b" : {
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_1" : [
        "c0a64e40-7542-45e9-8844-6623c6c0b17a",
        "c0a64e40-7542-45e9-8844-6623c6c0b17a"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Paragraph_2" : [
        "c0a64e40-7542-45e9-8844-6623c6c0b17a"
      ],
      "Paragraph_3" : [
        "d77f7d0c-efbd-4b3a-a517-656d9fa9c17b"
      ]
    },
    "56859ee9-37a8-4794-9e05-a83e3d66248a" : {
      "Paragraph_1" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ],
      "Paragraph_2" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ]
    },
    "fc609c7f-6e37-4c8f-a46e-f6522662c61f" : {
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "64e9d709-c724-47bf-a13e-0c7141f1ce97" : {
      "Paragraph_1" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ],
      "Paragraph_2" : [
        "06f87fda-20e2-4200-982c-f716ff064826"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);