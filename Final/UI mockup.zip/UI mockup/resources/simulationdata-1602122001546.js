function initData() {
  jimData.datamasters["Past redemptions and expenditures"] = [
    {
      "id": 1,
      "datamaster": "Past redemptions and expenditures",
      "userdata": {
        "6b3e5e87-9eab-4210-9d90-bec0c1d23469": "sample text",
        "e0240cf2-0b44-4b0b-a071-70ef61acca57": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "Past redemptions and expenditures",
      "userdata": {
        "6b3e5e87-9eab-4210-9d90-bec0c1d23469": "sample text",
        "e0240cf2-0b44-4b0b-a071-70ef61acca57": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "Past redemptions and expenditures",
      "userdata": {
        "6b3e5e87-9eab-4210-9d90-bec0c1d23469": "sample text",
        "e0240cf2-0b44-4b0b-a071-70ef61acca57": "sample text"
      }
    }
  ];

  jimData.isInitialized = true;
}