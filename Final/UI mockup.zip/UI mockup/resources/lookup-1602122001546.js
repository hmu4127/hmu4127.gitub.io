(function(window, undefined) {
  var dictionary = {
    "06f87fda-20e2-4200-982c-f716ff064826": "Logged in",
    "23eb2b4b-a1bd-4696-aa07-21e4749fdb2a": "Forgot Password",
    "c0a64e40-7542-45e9-8844-6623c6c0b17a": "Login",
    "11ab9acc-0d15-4821-b2c4-0eeaf8bb8e97": "Account Manager",
    "3ebd9f51-6701-4e73-a2b8-5102a17823af": "Picture Submition",
    "8ee17b5d-ce74-464d-8763-a75cc3589538": "Point Redeem",
    "d77f7d0c-efbd-4b3a-a517-656d9fa9c17b": "Sign Up",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Home Screen",
    "56859ee9-37a8-4794-9e05-a83e3d66248a": "Balance check",
    "fc609c7f-6e37-4c8f-a46e-f6522662c61f": "Forgot Username",
    "64e9d709-c724-47bf-a13e-0c7141f1ce97": "Leaderboards",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);